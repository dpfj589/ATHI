package com.kosmo.athi.command;

import org.springframework.ui.Model;

public interface ICommand {

	public void execute(Model model);
}
